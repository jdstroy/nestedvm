char *foo()
{
  return FOO;
}
