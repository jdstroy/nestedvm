#include <stdio.h>

void foo ()
{
  puts ("OK");
}
