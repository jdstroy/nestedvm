#ifndef Funny
#define Funny 1
#endif

{**}
{**}
