var s: string(40); external name 'S';

procedure print_globals; external name 'Print_globals';
