/* A Bison parser, made by GNU Bison 1.875b.  */

/* Skeleton parser for GLR parsing with Bison,
   Copyright (C) 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     prec_if = 258,
     prec_lower_than_error = 259,
     prec_import = 260,
     p_operator = 261,
     p_destructor = 262,
     p_constructor = 263,
     p_implementation = 264,
     p_uses = 265,
     p_else = 266,
     p_and = 267,
     p_array = 268,
     p_begin = 269,
     p_case = 270,
     p_div = 271,
     p_do = 272,
     p_downto = 273,
     p_end = 274,
     p_file = 275,
     p_for = 276,
     p_function = 277,
     p_goto = 278,
     p_if = 279,
     p_in = 280,
     p_label = 281,
     p_mod = 282,
     p_nil = 283,
     p_not = 284,
     p_of = 285,
     p_or = 286,
     p_packed = 287,
     p_procedure = 288,
     p_to = 289,
     p_program = 290,
     p_record = 291,
     p_repeat = 292,
     p_set = 293,
     p_then = 294,
     p_type = 295,
     p_until = 296,
     p_var = 297,
     p_while = 298,
     p_with = 299,
     p_absolute = 300,
     p_abstract = 301,
     p_and_then = 302,
     p_as = 303,
     p_asm = 304,
     p_attribute = 305,
     p_bindable = 306,
     p_const = 307,
     p_external = 308,
     p_far = 309,
     p_finalization = 310,
     p_forward = 311,
     p_import = 312,
     p_inherited = 313,
     p_initialization = 314,
     p_is = 315,
     p_near = 316,
     p_object = 317,
     p_only = 318,
     p_otherwise = 319,
     p_or_else = 320,
     p_pow = 321,
     p_restricted = 322,
     p_shl = 323,
     p_shr = 324,
     p_unit = 325,
     p_value = 326,
     p_virtual = 327,
     p_xor = 328,
     p_asmname = 329,
     p_c = 330,
     p_c_language = 331,
     p_Addr = 332,
     p_Assigned = 333,
     p_Dispose = 334,
     p_FormatString = 335,
     p_New = 336,
     p_Return = 337,
     LEX_ID = 338,
     LEX_BUILTIN_PROCEDURE = 339,
     LEX_BUILTIN_PROCEDURE_WRITE = 340,
     LEX_BUILTIN_FUNCTION = 341,
     LEX_BUILTIN_FUNCTION_VT = 342,
     LEX_BUILTIN_VARIABLE = 343,
     LEX_INTCONST = 344,
     LEX_INTCONST_BASE = 345,
     LEX_STRCONST = 346,
     LEX_REALCONST = 347,
     LEX_CARET_WHITE = 348,
     LEX_CARET_LETTER = 349,
     BOGUS = 350,
     LEX_CONST_EQUAL = 351,
     LEX_RPAR = 352,
     LEX_BPPLUS = 353,
     LEX_BPMINUS = 354,
     LEX_RANGE = 355,
     LEX_ELLIPSIS = 356,
     LEX_RENAME = 357,
     LEX_SYMDIFF = 358,
     LEX_ASSIGN = 359,
     LEX_NE = 360,
     LEX_GE = 361,
     LEX_LE = 362,
     LEX_POWER = 363,
     LEX_CEIL_PLUS = 364,
     LEX_CEIL_MINUS = 365,
     LEX_FLOOR_PLUS = 366,
     LEX_FLOOR_MINUS = 367,
     LEX_CEIL_MULT = 368,
     LEX_CEIL_DIV = 369,
     LEX_FLOOR_MULT = 370,
     LEX_FLOOR_DIV = 371
   };
#endif
#define prec_if 258
#define prec_lower_than_error 259
#define prec_import 260
#define p_operator 261
#define p_destructor 262
#define p_constructor 263
#define p_implementation 264
#define p_uses 265
#define p_else 266
#define p_and 267
#define p_array 268
#define p_begin 269
#define p_case 270
#define p_div 271
#define p_do 272
#define p_downto 273
#define p_end 274
#define p_file 275
#define p_for 276
#define p_function 277
#define p_goto 278
#define p_if 279
#define p_in 280
#define p_label 281
#define p_mod 282
#define p_nil 283
#define p_not 284
#define p_of 285
#define p_or 286
#define p_packed 287
#define p_procedure 288
#define p_to 289
#define p_program 290
#define p_record 291
#define p_repeat 292
#define p_set 293
#define p_then 294
#define p_type 295
#define p_until 296
#define p_var 297
#define p_while 298
#define p_with 299
#define p_absolute 300
#define p_abstract 301
#define p_and_then 302
#define p_as 303
#define p_asm 304
#define p_attribute 305
#define p_bindable 306
#define p_const 307
#define p_external 308
#define p_far 309
#define p_finalization 310
#define p_forward 311
#define p_import 312
#define p_inherited 313
#define p_initialization 314
#define p_is 315
#define p_near 316
#define p_object 317
#define p_only 318
#define p_otherwise 319
#define p_or_else 320
#define p_pow 321
#define p_restricted 322
#define p_shl 323
#define p_shr 324
#define p_unit 325
#define p_value 326
#define p_virtual 327
#define p_xor 328
#define p_asmname 329
#define p_c 330
#define p_c_language 331
#define p_Addr 332
#define p_Assigned 333
#define p_Dispose 334
#define p_FormatString 335
#define p_New 336
#define p_Return 337
#define LEX_ID 338
#define LEX_BUILTIN_PROCEDURE 339
#define LEX_BUILTIN_PROCEDURE_WRITE 340
#define LEX_BUILTIN_FUNCTION 341
#define LEX_BUILTIN_FUNCTION_VT 342
#define LEX_BUILTIN_VARIABLE 343
#define LEX_INTCONST 344
#define LEX_INTCONST_BASE 345
#define LEX_STRCONST 346
#define LEX_REALCONST 347
#define LEX_CARET_WHITE 348
#define LEX_CARET_LETTER 349
#define BOGUS 350
#define LEX_CONST_EQUAL 351
#define LEX_RPAR 352
#define LEX_BPPLUS 353
#define LEX_BPMINUS 354
#define LEX_RANGE 355
#define LEX_ELLIPSIS 356
#define LEX_RENAME 357
#define LEX_SYMDIFF 358
#define LEX_ASSIGN 359
#define LEX_NE 360
#define LEX_GE 361
#define LEX_LE 362
#define LEX_POWER 363
#define LEX_CEIL_PLUS 364
#define LEX_CEIL_MINUS 365
#define LEX_FLOOR_PLUS 366
#define LEX_FLOOR_MINUS 367
#define LEX_CEIL_MULT 368
#define LEX_CEIL_DIV 369
#define LEX_FLOOR_MULT 370
#define LEX_FLOOR_DIV 371




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 103 "parse.y"
typedef union YYSTYPE {
  enum tree_code code;
  long itype;
  tree ttype;
} YYSTYPE;
/* Line 2066 of glr.c.  */
#line 270 "parse.h"
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{

  int first_line;
  int first_column;
  int last_line;
  int last_column;

} YYLTYPE;
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;


