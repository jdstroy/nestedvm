/* Generated automatically by the Makefile.
   DO NOT CHANGE THIS FILE MANUALLY! */

#define GPC_MAJOR "2"
#define GPC_MINOR "1"
#define GPC_VERSION_STRING "20030830"
#define GPC_RELEASE_STRING GPC_VERSION_STRING
